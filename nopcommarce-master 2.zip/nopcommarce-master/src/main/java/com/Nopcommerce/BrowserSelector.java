package com.Nopcommerce;

public class BrowserSelector extends BasePage {
}
