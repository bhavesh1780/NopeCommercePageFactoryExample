package com.Nopcommerce;

public class LoadProperty {
}
